package com.example.felixcarelaapplication;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import android.widget.Button;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import java.util.List;

public class InventoryAdapter extends RecyclerView.Adapter<InventoryAdapter.ViewHolder> {
    private Context context;
    private List<InventoryItem> itemList;
    private ItemActionListener actionListener;

    public InventoryAdapter(Context context, List<InventoryItem> itemList, ItemActionListener listener) {
        this.context = context;
        this.itemList = itemList;
        this.actionListener = listener;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.item_inventory, parent, false);
        return new ViewHolder(view, actionListener, itemList);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        InventoryItem item = itemList.get(position);
        holder.bind(item);
    }

    @Override
    public int getItemCount() {
        return itemList.size();
    }

    public void setItems(List<InventoryItem> items) {
        this.itemList = items;
        notifyDataSetChanged();
    }

    public static class ViewHolder extends RecyclerView.ViewHolder {
        TextView itemName;
        Button deleteButton, updateButton;
        ItemActionListener actionListener;

        public ViewHolder(View itemView, ItemActionListener listener, List<InventoryItem> itemList) {
            super(itemView);
            this.actionListener = listener;
            itemName = itemView.findViewById(R.id.nameTextView);
            deleteButton = itemView.findViewById(R.id.deleteButton);
            updateButton = itemView.findViewById(R.id.updateButton);

            deleteButton.setOnClickListener(v -> {
                int position = getAdapterPosition();
                if (position != RecyclerView.NO_POSITION) {
                    actionListener.onDeleteItem(itemList.get(position).getId());
                }
            });

            updateButton.setOnClickListener(v -> {
                int position = getAdapterPosition();
                if (position != RecyclerView.NO_POSITION) {
                    actionListener.onUpdateItem(itemList.get(position));
                }
            });
        }

        public void bind(InventoryItem item) {
            itemName.setText("ID: " + item.getId() + " - Name: " + item.getName() + "\nQuantity: " + item.getQuantity());
        }
    }

    public interface ItemActionListener {
        void onDeleteItem(int itemId);
        void onUpdateItem(InventoryItem item);
    }
}
