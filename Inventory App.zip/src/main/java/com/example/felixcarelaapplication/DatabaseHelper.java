package com.example.felixcarelaapplication;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import java.util.List;
import java.util.ArrayList;
import android.util.Log;

public class DatabaseHelper extends SQLiteOpenHelper {
    private static final int DATABASE_VERSION = 6;
    private static final String DATABASE_NAME = "InventoryApp.db";

    // User table constants
    private static final String TABLE_USER = "user";
    private static final String COLUMN_USER_ID = "user_id";
    private static final String COLUMN_USER_NAME = "user_name";
    private static final String COLUMN_USER_PASSWORD = "user_password";
    private static final String CREATE_USER_TABLE = "CREATE TABLE " + TABLE_USER + "("
            + COLUMN_USER_ID + " INTEGER PRIMARY KEY AUTOINCREMENT,"
            + COLUMN_USER_NAME + " TEXT," + COLUMN_USER_PASSWORD + " TEXT" + ")";
    private static final String DROP_USER_TABLE = "DROP TABLE IF EXISTS " + TABLE_USER;

    // Inventory table constants
    private static final String TABLE_INVENTORY = "inventory";
    private static final String COLUMN_ITEM_ID = "item_id";
    private static final String COLUMN_ITEM_NAME = "item_name";
    private static final String COLUMN_ITEM_QUANTITY = "item_quantity";
    private static final String CREATE_INVENTORY_TABLE = "CREATE TABLE " + TABLE_INVENTORY + "("
            + COLUMN_ITEM_ID + " INTEGER PRIMARY KEY AUTOINCREMENT,"
            + COLUMN_ITEM_NAME + " TEXT,"
            + COLUMN_ITEM_QUANTITY + " INTEGER" + ")";

    public DatabaseHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL(CREATE_USER_TABLE);
        db.execSQL(CREATE_INVENTORY_TABLE);
        initializeInventory(db);
    }

    private void initializeInventory(SQLiteDatabase db) {
        for (int i = 1; i <= 8; i++) {
            ContentValues values = new ContentValues();
            values.put(COLUMN_ITEM_ID, i);  // Explicitly set the ID
            values.put(COLUMN_ITEM_NAME, "Item " + i);
            values.put(COLUMN_ITEM_QUANTITY, 10 + i);
            long result = db.insert(TABLE_INVENTORY, null, values);
            if (result == -1) {
                Log.e("DBHelper", "Failed to insert data for item " + i);
            }
        }
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL(DROP_USER_TABLE);
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_INVENTORY);
        onCreate(db);
    }

    public void addUser(String username, String password) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(COLUMN_USER_NAME, username);
        values.put(COLUMN_USER_PASSWORD, password);
        db.insert(TABLE_USER, null, values);
        db.close();
    }

    public boolean checkUser(String username, String password) {
        SQLiteDatabase db = this.getReadableDatabase();
        String[] columns = {COLUMN_USER_NAME};
        String selection = COLUMN_USER_NAME + "=? AND " + COLUMN_USER_PASSWORD + "=?";
        String[] selectionArgs = {username, password};
        Cursor cursor = db.query(TABLE_USER, columns, selection, selectionArgs, null, null, null);
        int cursorCount = cursor.getCount();
        cursor.close();
        db.close();
        return cursorCount > 0;
    }

    public List<InventoryItem> getAllItems() {
        List<InventoryItem> itemList = new ArrayList<>();
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.query(TABLE_INVENTORY, new String[]{COLUMN_ITEM_ID, COLUMN_ITEM_NAME, COLUMN_ITEM_QUANTITY}, null, null, null, null, null);

        if (cursor.moveToFirst()) {
            do {
                int id = cursor.getInt(cursor.getColumnIndexOrThrow(COLUMN_ITEM_ID));
                String name = cursor.getString(cursor.getColumnIndexOrThrow(COLUMN_ITEM_NAME));
                int quantity = cursor.getInt(cursor.getColumnIndexOrThrow(COLUMN_ITEM_QUANTITY));
                itemList.add(new InventoryItem(id, name, quantity));  // Update this line
            } while (cursor.moveToNext());
        }
        cursor.close();
        db.close();
        return itemList;
    }

    public List<InventoryItem> getLowInventoryItems() {
        List<InventoryItem> lowInventoryItems = new ArrayList<>();
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.query(TABLE_INVENTORY,
                new String[]{COLUMN_ITEM_ID, COLUMN_ITEM_NAME, COLUMN_ITEM_QUANTITY},
                COLUMN_ITEM_QUANTITY + " <= ?",
                new String[]{"5"}, null, null, null);

        if (cursor.moveToFirst()) {
            do {
                int id = cursor.getInt(cursor.getColumnIndex(COLUMN_ITEM_ID));
                String name = cursor.getString(cursor.getColumnIndex(COLUMN_ITEM_NAME));
                int quantity = cursor.getInt(cursor.getColumnIndex(COLUMN_ITEM_QUANTITY));
                lowInventoryItems.add(new InventoryItem(id, name, quantity));
            } while (cursor.moveToNext());
        }
        cursor.close();
        db.close();
        return lowInventoryItems;
    }

    public void addItem(InventoryItem item) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(COLUMN_ITEM_NAME, item.getName());
        values.put(COLUMN_ITEM_QUANTITY, item.getQuantity());

        // Inserting Row
        long newRowId = db.insert(TABLE_INVENTORY, null, values);
        if (newRowId != -1) {
            item.setId((int) newRowId);
            Log.d("DatabaseHelper", "New item inserted with id: " + newRowId);
        } else {
            Log.e("DatabaseHelper", "Failed to insert new item");
        }
        db.close();
    }

    public String deleteItem(int id) {
        SQLiteDatabase db = this.getWritableDatabase();
        String deletedItemName = null;

        // Log statement to track the attempt to delete an item
        Log.d("DatabaseHelper", "Attempting to delete item with ID: " + id);

        // Query to fetch the name of the item before deletion
        Cursor cursor = db.query(TABLE_INVENTORY, new String[]{COLUMN_ITEM_NAME}, COLUMN_ITEM_ID + " = ?", new String[]{String.valueOf(id)}, null, null, null);
        if (cursor.moveToFirst()) {
            deletedItemName = cursor.getString(cursor.getColumnIndex(COLUMN_ITEM_NAME));
        }
        cursor.close();

        // Perform the deletion of the item
        int deletedRows = db.delete(TABLE_INVENTORY, COLUMN_ITEM_ID + " = ?", new String[]{String.valueOf(id)});
        if (deletedRows > 0) {
            Log.d("DatabaseHelper", "Item deleted successfully");
        } else {
            Log.d("DatabaseHelper", "Failed to delete item");
        }

        db.close();
        return deletedItemName;
    }

    public void updateItem(InventoryItem item) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(COLUMN_ITEM_NAME, item.getName());
        values.put(COLUMN_ITEM_QUANTITY, item.getQuantity());

        // Update the database record for the given item ID
        db.update(TABLE_INVENTORY, values, COLUMN_ITEM_ID + " = ?", new String[]{String.valueOf(item.getId())});
        db.close();
    }
}
