package com.example.felixcarelaapplication;

import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import android.content.Intent;

public class LoginActivity extends AppCompatActivity {
    private EditText usernameEditText;
    private EditText passwordEditText;
    private Button loginButton;
    private Button createAccountButton;
    private DatabaseHelper databaseHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);
        databaseHelper = new DatabaseHelper(this);

        // Initialize views
        usernameEditText = findViewById(R.id.usernameEditText);
        passwordEditText = findViewById(R.id.passwordEditText);
        loginButton = findViewById(R.id.loginButton);
        createAccountButton = findViewById(R.id.createAccountButton);

        // Set button click listeners
        loginButton.setOnClickListener(v -> verifyFromDatabase());
        createAccountButton.setOnClickListener(v -> addUserToDatabase());
    }

    private void verifyFromDatabase() {
        String username = usernameEditText.getText().toString().trim();
        String password = passwordEditText.getText().toString().trim();
        if (databaseHelper.checkUser(username, password)) {
            Toast.makeText(LoginActivity.this, "Login Successful", Toast.LENGTH_SHORT).show();

            // Correctly create an Intent to start InventoryActivity
            Intent intent = new Intent(LoginActivity.this, InventoryActivity.class);
            startActivity(intent);
            finish();
        } else {
            Toast.makeText(LoginActivity.this, "Invalid Credentials", Toast.LENGTH_SHORT).show();
        }
    }

    private void addUserToDatabase() {
        // Retrieve username and password from input fields
        String username = usernameEditText.getText().toString().trim();
        String password = passwordEditText.getText().toString().trim();

        // Ensure fields are not empty
        if (!username.isEmpty() && !password.isEmpty()) {
            // Add user to database
            databaseHelper.addUser(username, password);
            // Display success message
            Toast.makeText(LoginActivity.this, "Account Created Successfully", Toast.LENGTH_SHORT).show();
        } else {
            // Display error message if fields are empty
            Toast.makeText(LoginActivity.this, "Please enter all details", Toast.LENGTH_SHORT).show();
        }
    }
}
