package com.example.felixcarelaapplication;

import android.content.res.Configuration;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import java.util.List;
import android.app.Dialog;
import android.widget.TextView;
import android.Manifest;
import android.content.pm.PackageManager;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import android.widget.Switch;
import android.telephony.SmsManager;

public class InventoryActivity extends AppCompatActivity implements InventoryAdapter.ItemActionListener {
    private RecyclerView inventoryRecyclerView;
    private InventoryAdapter adapter;
    private DatabaseHelper databaseHelper;
    private Button addButton;
    private Switch smsSwitch;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_inventory);

        databaseHelper = new DatabaseHelper(this);
        inventoryRecyclerView = findViewById(R.id.inventoryRecyclerView);
        addButton = findViewById(R.id.addButton);
        smsSwitch = findViewById(R.id.smsSwitch);

        setupRecyclerView();
        setupAddButtonListener();
        setupSMSPermissionSwitch();
    }

    private void setupRecyclerView() {
        int numberOfColumns = getResources().getConfiguration().orientation == Configuration.ORIENTATION_LANDSCAPE ? 2 : 1;
        inventoryRecyclerView.setLayoutManager(new GridLayoutManager(this, numberOfColumns));
        List<InventoryItem> items = databaseHelper.getAllItems();
        adapter = new InventoryAdapter(this, items, this);
        inventoryRecyclerView.setAdapter(adapter);
    }

    private void setupAddButtonListener() {
        addButton.setOnClickListener(v -> showAddItemDialog());
    }

    private void setupSMSPermissionSwitch() {
        smsSwitch.setOnCheckedChangeListener((buttonView, isChecked) -> {
            if (isChecked) {
                if (ContextCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS) != PackageManager.PERMISSION_GRANTED) {
                    ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.SEND_SMS}, 1);
                }
            } else {
                Toast.makeText(this, "SMS Alerts Disabled", Toast.LENGTH_SHORT).show();
            }
        });
        // Set the initial state of the switch based on whether permission has been granted
        boolean hasPermission = ContextCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS) == PackageManager.PERMISSION_GRANTED;
        smsSwitch.setChecked(hasPermission);
        if (hasPermission) {
            Toast.makeText(this, "SMS Alerts are enabled", Toast.LENGTH_SHORT).show();
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == 1) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                smsSwitch.setChecked(true);
                Toast.makeText(this, "SMS permission granted", Toast.LENGTH_SHORT).show();
            } else {
                smsSwitch.setChecked(false);
                Toast.makeText(this, "SMS permission denied", Toast.LENGTH_SHORT).show();
            }
        }
    }

    @Override
    public void onDeleteItem(int itemId) {
        String deletedItemName = databaseHelper.deleteItem(itemId);
        if (deletedItemName != null) {
            Toast.makeText(this, "Deleted: " + deletedItemName, Toast.LENGTH_SHORT).show();
        } else {
            Toast.makeText(this, "Failed to delete item", Toast.LENGTH_SHORT).show();
        }
        updateItems();
    }

    @Override
    public void onUpdateItem(InventoryItem item) {
        showEditItemDialog(item);
    }

    private void showEditItemDialog(InventoryItem item) {
        Dialog dialog = new Dialog(this);
        dialog.setContentView(R.layout.edit_item_dialog);
        TextView itemIdTextView = dialog.findViewById(R.id.itemIdTextView);
        EditText itemNameEditText = dialog.findViewById(R.id.editItemNameEditText);
        EditText itemQuantityEditText = dialog.findViewById(R.id.editItemQuantityEditText);
        Button updateItemButton = dialog.findViewById(R.id.updateItemButton);

        itemIdTextView.setText(String.valueOf(item.getId())); // Set text to display item ID
        itemNameEditText.setText(item.getName());
        itemQuantityEditText.setText(String.valueOf(item.getQuantity()));

        updateItemButton.setOnClickListener(v -> {
            String newName = itemNameEditText.getText().toString().trim();
            int newQuantity = Integer.parseInt(itemQuantityEditText.getText().toString().trim());

            item.setName(newName);
            item.setQuantity(newQuantity);
            databaseHelper.updateItem(item);

            dialog.dismiss();
            updateItems();
        });

        dialog.show();
    }

    private void showAddItemDialog() {
        Dialog dialog = new Dialog(this);
        dialog.setContentView(R.layout.add_item_dialog);
        EditText itemIdEditText = dialog.findViewById(R.id.itemIdEditText);
        EditText itemNameEditText = dialog.findViewById(R.id.itemNameEditText);
        EditText itemQuantityEditText = dialog.findViewById(R.id.itemQuantityEditText);
        Button addItemButton = dialog.findViewById(R.id.addItemButton);

        addItemButton.setOnClickListener(v -> {
            int itemId = Integer.parseInt(itemIdEditText.getText().toString().trim());
            String itemName = itemNameEditText.getText().toString().trim();
            int itemQuantity = Integer.parseInt(itemQuantityEditText.getText().toString().trim());

            InventoryItem newItem = new InventoryItem(itemId, itemName, itemQuantity);
            databaseHelper.addItem(newItem);

            dialog.dismiss();
            updateItems();
        });

        dialog.show();
    }

    private void updateItems() {
        adapter.setItems(databaseHelper.getAllItems());
        adapter.notifyDataSetChanged();
        sendLowInventoryAlerts(); // Check for low inventory after updating items
    }

    private void sendLowInventoryAlerts() {
        if (smsSwitch.isChecked() && ContextCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS) == PackageManager.PERMISSION_GRANTED) {
            List<InventoryItem> lowInventoryItems = databaseHelper.getLowInventoryItems();
            SmsManager smsManager = SmsManager.getDefault();
            for (InventoryItem item : lowInventoryItems) {
                smsManager.sendTextMessage("PHONE_NUMBER_HERE", null, "Low inventory alert: " + item.getName() + " has only " + item.getQuantity() + " items left.", null, null);
            }
        }
    }
}
